"""
Backtesting script for ETH and SOL models over offline datasets.

This script can be executed as a standalone program or imported as a module.
It uses the same feature engineering pipeline employed during training and
applies the trained CatBoost models to historical data to assess
performance.  Only trades with predicted probability ≥ 0.5 are taken.

Usage:
    python backtest.py --asset ETH --one-min-files ETHUSDT_1m_2023-08_to_2024-02.zip \
                       --htf-file oldETH5m15m30m1h4h.zip --model-file eth_model.pkl

Outputs summary statistics and saves trade logs and weekly stats to CSV.
"""

import argparse
import os
import sys
import pandas as pd
from typing import List
from catboost import CatBoostClassifier
from datetime import datetime

# Append parent directory to path so that model_training can be imported when this
# script resides in a subpackage.
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(current_dir, '..'))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

from model_training import (
    load_1m_zip,
    load_htf_zip,
    merge_features,
    generate_candidate_signals,
    backtest_signals,
    prepare_dataset,
)


def backtest_asset(one_min_files: List[str], htf_file: str, model_path: str, include_extra: bool = True,
                   log_prefix: str = 'output') -> None:
    """Backtest a trained model on historical data.

    Args:
        one_min_files: List of ZIP filenames containing 1m candles to backtest on.
        htf_file: ZIP filename with higher timeframe candles.
        model_path: Path to the trained CatBoost model.
        include_extra: Whether to include 15m/30m features (True for ETH/SOL).
        log_prefix: Prefix used for output CSV filenames.

    The function writes `<log_prefix>_trades.csv` and `<log_prefix>_weekly.csv`
    to the current directory and prints summary statistics.
    """
    df1m = load_1m_zip(one_min_files)
    htf = load_htf_zip(htf_file)
    merged = merge_features(df1m, htf, include_extra=include_extra)
    signals = generate_candidate_signals(merged)
    print(f"Total candidate signals: {len(signals)}")
    # Load model with joblib/pickle.  The models were saved using joblib during
    # training, so we load them via joblib rather than CatBoost's load_model.
    import joblib
    model = joblib.load(model_path)
    # Prepare feature matrix for all signals
    feature_cols = ['rsi5m', 'ema_diff5m', 'ratio1h', 'ratio4h', 'ratio1m', 'body_strength']
    if include_extra:
        feature_cols += ['ema_diff15m', 'ema_diff30m', 'ratio15m', 'ratio30m', 'rsi15m']
    X_all = signals[feature_cols].copy()
    probs = model.predict_proba(X_all)[:, 1]
    signals = signals.assign(prob=probs)
    # Only simulate trades with probability ≥ 0.5
    selected_signals = signals[signals['prob'] >= 0.5].copy()
    print(f"Signals with prob ≥ 0.5: {len(selected_signals)}")
    trade_results = backtest_signals(selected_signals, df1m)
    # Compute statistics
    wins = trade_results[trade_results['outcome']=='win']
    losses = trade_results[trade_results['outcome']=='loss']
    total_trades = len(trade_results)
    accuracy = len(wins) / total_trades if total_trades else 0
    profit_factor = wins['pnl'].sum() / abs(losses['pnl'].sum()) if not losses.empty else float('inf')
    print(f"Backtest trades: {total_trades}, wins: {len(wins)}, accuracy: {accuracy:.3f}, PF: {profit_factor:.2f}")
    # Save trade log
    trades_csv = f"{log_prefix}_trades.csv"
    trade_results.to_csv(trades_csv, index=False)
    # Weekly stats
    trade_results['year'] = trade_results['datetime'].dt.isocalendar().year
    trade_results['week'] = trade_results['datetime'].dt.isocalendar().week
    trade_results['win'] = (trade_results['outcome']=='win').astype(int)
    weekly = trade_results.groupby(['year','week']).agg(trades=('win','count'), wins=('win','sum'))
    weekly['losses'] = weekly['trades'] - weekly['wins']
    weekly['accuracy'] = weekly['wins'] / weekly['trades']
    weekly_csv = f"{log_prefix}_weekly.csv"
    weekly.reset_index().to_csv(weekly_csv, index=False)
    print(f"Saved trade log to {trades_csv} and weekly stats to {weekly_csv}")


def main():
    parser = argparse.ArgumentParser(description='Backtest ETH/SOL model on historical data.')
    parser.add_argument('--asset', choices=['ETH', 'SOL'], required=True, help='Asset to backtest')
    parser.add_argument('--one-min-files', nargs='+', required=True, help='List of 1m candle ZIP files')
    parser.add_argument('--htf-file', required=True, help='Higher timeframe ZIP file')
    parser.add_argument('--model-file', required=True, help='Trained CatBoost model file')
    parser.add_argument('--log-prefix', default='backtest', help='Prefix for output CSV files')
    args = parser.parse_args()
    include_extra = True  # always include extra features for ETH/SOL models
    backtest_asset(args.one_min_files, args.htf_file, args.model_file, include_extra, args.log_prefix)


if __name__ == '__main__':
    main()