"""
Indicator functions for the ETH/SOL trading bot.

This module provides simple implementations of exponential moving average (EMA),
relative strength index (RSI) and candle body strength.  They mirror the
implementations used in the original BTC bot so that feature computation
is consistent between backtesting and live usage.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

def ema(series: pd.Series, span: int) -> pd.Series:
    """Compute the exponential moving average (EMA) of a series.

    Args:
        series: Input series of numeric values.
        span: EMA span (period).

    Returns:
        Pandas Series of the same length containing the EMA.
    """
    return series.ewm(span=span, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Compute the Relative Strength Index (RSI) of a price series.

    RSI oscillates between 0 and 100 and is based on average gains and
    losses over the specified window.  It is often used to identify
    overbought and oversold conditions.

    Args:
        series: Series of close prices.
        period: Number of periods to use when calculating average gain and
            average loss (default 14).

    Returns:
        Pandas Series of RSI values aligned with the input series.
    """
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    # Avoid division by zero
    rs = avg_gain / avg_loss.replace({0: np.nan})
    rsi = 100 - (100 / (1 + rs))
    return rsi


def candle_body_strength(open_: pd.Series, close: pd.Series, high: pd.Series, low: pd.Series) -> pd.Series:
    """Compute the ratio of the candle body size to its total range.

    The body strength is defined as (close ‑ open) / (high ‑ low).  A
    value above zero indicates a bullish candle and below zero a bearish
    candle.  Larger absolute values indicate stronger momentum within the
    candle.  When the high and low are equal the denominator is set to
    one to avoid division by zero.

    Args:
        open_: Series of open prices.
        close: Series of close prices.
        high: Series of high prices.
        low: Series of low prices.

    Returns:
        Series of candle body strength values.
    """
    body = close - open_
    range_ = high - low
    range_safe = range_.replace(0, 1)
    return body / range_safe