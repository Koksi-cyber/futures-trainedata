"""
Trading bot classes for ETH and SOL based on CatBoost models.

This module defines a generic `TradeBotAsset` class that loads a pre‑trained
CatBoost model and computes the necessary features from real‑time Binance
candle data.  It is modelled after the BTC bot included in the original
`final_result.zip` but extended to handle additional timeframes (15m and
30m) and features required by the ETH and SOL models.  Two convenience
classes (`TradeBotETH` and `TradeBotSOL`) set the appropriate symbol,
model file and feature dimensions.

Example usage:

```python
from trade_bot import TradeBotETH
bot = TradeBotETH(threshold=0.5)
bot.refresh_candles()
signal = bot.generate_signal()
if signal:
    print(signal)
```
"""

import os
import joblib
import requests
import pandas as pd
from dataclasses import dataclass
from typing import Optional, List

from .indicators import ema, rsi, candle_body_strength

BINANCE_URL = "https://fapi.binance.com"

def fetch_klines(symbol: str, interval: str, limit: int = 500) -> pd.DataFrame:
    """Fetch recent candlestick data from Binance Futures REST API.

    Args:
        symbol: Trading pair symbol, e.g. ``'ETHUSDT'``.
        interval: Kline interval such as ``'1m'``, ``'5m'``, ``'15m'``,
            ``'30m'``, ``'1h'``, ``'4h'``.
        limit: Number of candles to fetch (default 500).

    Returns:
        DataFrame with columns ``time``, ``open``, ``high``, ``low``, ``close``.
    """
    url = f"{BINANCE_URL}/fapi/v1/klines"
    params = {"symbol": symbol.upper(), "interval": interval, "limit": limit}
    resp = requests.get(url, params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    candles = [{
        "time": pd.to_datetime(k[0], unit="ms"),
        "open": float(k[1]),
        "high": float(k[2]),
        "low": float(k[3]),
        "close": float(k[4])
    } for k in data]
    return pd.DataFrame(candles)


@dataclass
class TradeSignal:
    """Simple container for a trade signal."""
    timestamp: pd.Timestamp
    direction: str
    probability: float
    entry_price: float
    stop_loss: float
    take_profit: float


class TradeBotAsset:
    """Base class for ETH/SOL trading bots with CatBoost models.

    Subclasses should override ``symbol`` and ``model_filename``.
    The `threshold` parameter controls the minimum model probability
    required to emit a signal.
    """

    symbol: str = "ETHUSDT"
    model_filename: str = "eth_model.pkl"
    threshold: float = 0.5

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold
        self.model = self.load_model()
        # DataFrames for different timeframes
        self.candles = {
            '1m': pd.DataFrame(),
            '5m': pd.DataFrame(),
            '15m': pd.DataFrame(),
            '30m': pd.DataFrame(),
            '1h': pd.DataFrame(),
            '4h': pd.DataFrame(),
        }

    def load_model(self):
        """Load the CatBoost model from disk."""
        model_path = os.path.join(os.path.dirname(__file__), self.model_filename)
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}")
        return joblib.load(model_path)

    def refresh_candles(self):
        """Fetch latest candles for all required intervals and compute indicators."""
        # 1m and 5m candles
        for interval in ['1m', '5m', '15m', '30m', '1h', '4h']:
            self.candles[interval] = fetch_klines(self.symbol, interval, 500)
        # Compute EMAs and RSI on required frames
        # 5m
        df5 = self.candles['5m']
        df5['ema20'] = ema(df5['close'], 20)
        df5['ema50'] = ema(df5['close'], 50)
        df5['rsi'] = rsi(df5['close'], 14)
        # 15m
        df15 = self.candles['15m']
        df15['ema20'] = ema(df15['close'], 20)
        df15['ema50'] = ema(df15['close'], 50)
        df15['rsi'] = rsi(df15['close'], 14)
        # 30m
        df30 = self.candles['30m']
        df30['ema20'] = ema(df30['close'], 20)
        df30['ema50'] = ema(df30['close'], 50)
        df30['rsi'] = rsi(df30['close'], 14)
        # 1h and 4h EMAs
        df1h = self.candles['1h']
        df1h['ema50'] = ema(df1h['close'], 50)
        df4h = self.candles['4h']
        df4h['ema50'] = ema(df4h['close'], 50)

    def compute_features(self) -> Optional[List[float]]:
        """Compute the feature vector for the most recent minute.

        Returns None if conditions are not met (no signal).
        The feature order matches the order used during model training.
        """
        if any(self.candles[tf].empty for tf in ['1m', '5m', '15m', '30m', '1h', '4h']):
            return None

        latest_1m = self.candles['1m'].iloc[-1]
        t = latest_1m['time']

        # Get latest rows up to current time for each timeframe
        row5 = self.candles['5m'][self.candles['5m']['time'] <= t].iloc[-1]
        row15 = self.candles['15m'][self.candles['15m']['time'] <= t].iloc[-1]
        row30 = self.candles['30m'][self.candles['30m']['time'] <= t].iloc[-1]
        row1h = self.candles['1h'][self.candles['1h']['time'] <= t].iloc[-1]
        row4h = self.candles['4h'][self.candles['4h']['time'] <= t].iloc[-1]

        # Trend filters: 1h and 4h close above EMA50
        if row4h['close'] <= row4h['ema50'] or row1h['close'] <= row1h['ema50']:
            return None
        # Momentum filter: 5m EMA20 > EMA50 and RSI5m < 55
        if row5['ema20'] <= row5['ema50'] or row5['rsi'] >= 55:
            return None

        # Compute risk (distance from entry to stop) and ensure positive
        prev_1m = self.candles['1m'].iloc[-2] if len(self.candles['1m']) > 1 else latest_1m
        risk = latest_1m['close'] - prev_1m['low']
        if risk <= 0:
            return None

        # Compute body strength
        body_strength_val = candle_body_strength(
            pd.Series([latest_1m['open']]),
            pd.Series([latest_1m['close']]),
            pd.Series([latest_1m['high']]),
            pd.Series([latest_1m['low']])
        ).iloc[0]

        # Feature vector (11 features)
        features = [
            row5['rsi'],
            row5['ema20'] - row5['ema50'],
            (row1h['close'] - row1h['ema50']) / row1h['ema50'],
            (row4h['close'] - row4h['ema50']) / row4h['ema50'],
            (latest_1m['close'] - row5['ema50']) / row5['ema50'],
            body_strength_val,
            row15['ema20'] - row15['ema50'],
            row30['ema20'] - row30['ema50'],
            # ratio15m: using 1h close vs 15m EMA50 as in training
            (row1h['close'] - row15['ema50']) / row15['ema50'],
            # ratio30m: 1h close vs 30m EMA50
            (row1h['close'] - row30['ema50']) / row30['ema50'],
            row15['rsi'],
        ]
        return features

    def generate_signal(self) -> Optional[TradeSignal]:
        """Generate a long trade signal if probability ≥ threshold."""
        features = self.compute_features()
        if features is None:
            return None

        prob = float(self.model.predict_proba([features])[0][1])
        if prob < self.threshold:
            return None

        latest = self.candles['1m'].iloc[-1]
        prev = self.candles['1m'].iloc[-2] if len(self.candles['1m']) > 1 else latest

        entry = latest['close']
        stop = prev['low']
        risk = entry - stop
        if risk <= 0:
            return None
        take = entry + 1.5 * risk

        return TradeSignal(
            timestamp=latest['time'],
            direction='LONG',
            probability=prob,
            entry_price=entry,
            stop_loss=stop,
            take_profit=take,
        )


class TradeBotETH(TradeBotAsset):
    """ETH‑specific trading bot."""
    symbol = 'ETHUSDT'
    model_filename = 'eth_model.pkl'


class TradeBotSOL(TradeBotAsset):
    """SOL‑specific trading bot."""
    symbol = 'SOLUSDT'
    model_filename = 'sol_model.pkl'