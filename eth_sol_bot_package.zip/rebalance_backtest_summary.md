# Re‑backtest and Live Bot Package for ETH & SOL

## Overview

This package extends the previously trained ETH and SOL CatBoost models to a
full‑year backtest and provides ready‑to‑run code for live signal generation.
The new datasets used for backtesting are the 1‑minute candles from August 2023
to February 2024 (`*_1m_2023-08_to_2024-02.zip`) together with the existing
higher‑timeframe candles (`oldETH5m15m30m1h4h.zip` and
`oldSOL5m15m30m1h4h.zip`).  The models were trained solely on the later
half‑year (February 2024 – August 2024), so this backtest reflects true
out‑of‑sample performance.

### Backtest Results

**ETHUSDT** (Aug 2023 – Feb 2024):

- Candidate signals: 29 179
- Trades taken (probability ≥ 0.5): 2 642
- Wins: 1 576
- Losses: 1 066
- **Accuracy:** 59.7 %
- **Profit factor:** 2.21

Weekly statistics show that the accuracy fluctuates between ~50 % and 70 % but
remains comfortably above the 54 % yearly requirement.  Detailed trade logs
are available in `eth_backtest_trades.csv` and weekly stats in
`eth_backtest_weekly.csv`.

**SOLUSDT** (Aug 2023 – Feb 2024):

- Candidate signals: 39 288
- Trades taken: 3 133
- Wins: 1 716
- Losses: 1 417
- **Accuracy:** 54.8 %
- **Profit factor:** 1.82

Although the SOL model’s accuracy on the out‑of‑sample period is lower than
ETH’s, it still exceeds the 54 % benchmark and maintains a profit factor
greater than 1.5.  Full logs are in `sol_backtest_trades.csv`, with
weekly stats in `sol_backtest_weekly.csv`.

## Live Bot Code

The `new_bot` directory contains a ready‑to‑run trading bot:

- `indicators.py` – EMA, RSI and body strength implementations.
- `trade_bot.py` – Generic `TradeBotAsset` class and convenience classes
  `TradeBotETH` and `TradeBotSOL`.  These classes fetch 1 m/5 m/15 m/30 m/1 h/4 h
  candles from Binance, compute the 11 features used during training and
  produce a `TradeSignal` when the model probability ≥ 0.5.
- `backtest.py` – Stand‑alone script to backtest a model on any historical
  dataset.  It loads candle ZIP files, computes features, filters signals
  using the model and simulates trades with the same TP/SL logic as the
  live bot.  Running the script writes detailed trade logs and weekly
  performance summaries to CSV.
- `eth_model.pkl` and `sol_model.pkl` – Pickled CatBoost models.

To run the bot in real time on ETHUSDT:

```python
from new_bot.trade_bot import TradeBotETH

bot = TradeBotETH(threshold=0.5)
bot.refresh_candles()    # fetch initial candles and compute indicators
signal = bot.generate_signal()
if signal:
    print(signal)
    # here you would execute a trade on your exchange
```

The same pattern applies for SOL by instantiating `TradeBotSOL`.

For offline testing on other datasets, use:

```bash
python new_bot/backtest.py \
  --asset ETH \
  --one-min-files ETHUSDT_1m_2023-08_to_2024-02.zip \
  --htf-file oldETH5m15m30m1h4h.zip \
  --model-file new_bot/eth_model.pkl \
  --log-prefix my_eth_test
```

## Files Included

- `new_bot/` – Python package with indicators, trading bot and backtest script.
- `eth_model.pkl`, `sol_model.pkl` – trained CatBoost models.
- `eth_backtest_trades.csv`, `eth_backtest_weekly.csv` – backtest logs for ETH.
- `sol_backtest_trades.csv`, `sol_backtest_weekly.csv` – backtest logs for SOL.
- `rebalance_backtest_summary.md` – this report.

All files are provided in the accompanying archive so you can reproduce
results or extend the bot for live trading.