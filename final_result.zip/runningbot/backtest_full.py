"""
Backtesting script for a full‑year BTCUSDT dataset.

This module replicates the feature engineering and long‑trade logic used by
the live bot.  It loads the one‑minute BTCUSDT candles (split across
``kline1.zip`` and ``kline2.zip``) and higher‑timeframe candles (5 minute,
1 hour and 4 hour) from the ``futures‑trainedata`` repository.  For each
minute bar it computes the same features that the random‑forest model
expects, applies the model to obtain a probability of success and, if
the probability exceeds a user‑defined threshold, simulates a long
trade with a 1.5× reward‑to‑risk target over a 20‑minute horizon.  The
results are saved to CSV files for further analysis.

Usage::

    python backtest_full.py --threshold 0.66 --data_path path/to/futures-trainedata

The script writes ``trades_summary.csv`` and ``weekly_summary.csv`` to
the current working directory.
"""

from __future__ import annotations

import argparse
import io
import json
import os
import zipfile
from pathlib import Path
from typing import List, Tuple

import joblib  # type: ignore
import numpy as np
import pandas as pd

from indicators import ema, rsi, candle_body_strength


def load_1m_candles(data_dir: Path) -> pd.DataFrame:
    """Load and concatenate the one‑minute BTCUSDT candles for one year.

    The data are expected to reside in ``kline1.zip`` and ``kline2.zip``
    within ``data_dir``.  Each archive must contain a JSON file whose
    name begins with ``BTCUSDT_1m_``.

    Parameters
    ----------
    data_dir : Path
        Base directory containing the kline zip files.

    Returns
    -------
    pd.DataFrame
        A DataFrame with columns ``time``, ``open``, ``high``, ``low`` and
        ``close`` sorted chronologically.
    """
    dfs: List[pd.DataFrame] = []
    for zip_name in ["kline1.zip", "kline2.zip"]:
        z_path = data_dir / zip_name
        if not z_path.exists():
            raise FileNotFoundError(f"Expected archive {z_path} not found")
        with zipfile.ZipFile(z_path) as zf:
            # pick the first JSON file inside the root folder
            json_names = [n for n in zf.namelist() if n.endswith(".json")]
            if not json_names:
                raise ValueError(f"No JSON files found in {z_path}")
            name = json_names[0]
            data = json.load(io.TextIOWrapper(zf.open(name)))
            df = pd.DataFrame({
                "time": pd.to_datetime([d["open_time"] for d in data]),
                "open": [float(d["open"]) for d in data],
                "high": [float(d["high"]) for d in data],
                "low": [float(d["low"]) for d in data],
                "close": [float(d["close"]) for d in data],
            })
            dfs.append(df)
    result = pd.concat(dfs).sort_values("time").reset_index(drop=True)
    return result


def load_tf_candles(data_dir: Path, timeframe: str) -> pd.DataFrame:
    """Load a higher‑timeframe candle file from ``kline3.zip``.

    Parameters
    ----------
    data_dir : Path
        Directory containing ``kline3.zip``.
    timeframe : str
        Timeframe key such as ``"5m"``, ``"1h"`` or ``"4h"``.

    Returns
    -------
    pd.DataFrame
        DataFrame of OHLC data for the specified timeframe.
    """
    z_path = data_dir / "kline3.zip"
    if not z_path.exists():
        raise FileNotFoundError(f"Expected archive {z_path} not found")
    with zipfile.ZipFile(z_path) as zf:
        json_name = f"kline3/BTCUSDT_{timeframe}_1y.json"
        with zf.open(json_name) as f:
            data = json.load(io.TextIOWrapper(f))
    return pd.DataFrame({
        "time": pd.to_datetime([d["open_time"] for d in data]),
        "open": [float(d["open"]) for d in data],
        "high": [float(d["high"]) for d in data],
        "low": [float(d["low"]) for d in data],
        "close": [float(d["close"]) for d in data],
    })


def build_merged(df1m: pd.DataFrame, df5m: pd.DataFrame, df1h: pd.DataFrame, df4h: pd.DataFrame) -> pd.DataFrame:
    """Merge lower and higher timeframes and compute features.

    The resulting DataFrame contains the necessary features for the long
    model: RSI, EMA differences, higher‑timeframe relative distances and
    candle body strength.  It also contains convenience columns such as
    ``prev_low`` and ``risk`` for backtesting.
    """
    # Indicator computation
    df5m = df5m.copy()
    df1h = df1h.copy()
    df4h = df4h.copy()
    df5m["ema20"] = ema(df5m["close"], 20)
    df5m["ema50"] = ema(df5m["close"], 50)
    df5m["rsi"] = rsi(df5m["close"], 14)
    df1h["ema50"] = ema(df1h["close"], 50)
    df4h["ema50"] = ema(df4h["close"], 50)
    # As‑of merges
    feat5 = df5m[["time", "ema20", "ema50", "rsi"]].rename(columns={
        "ema20": "ema20_5m",
        "ema50": "ema50_5m",
        "rsi": "rsi5m",
    })
    feat1 = df1h[["time", "ema50", "close"]].rename(columns={
        "ema50": "ema50_1h",
        "close": "close1h",
    })
    feat4 = df4h[["time", "ema50", "close"]].rename(columns={
        "ema50": "ema50_4h",
        "close": "close4h",
    })
    df1m = df1m.sort_values("time")
    feat5 = feat5.sort_values("time")
    feat1 = feat1.sort_values("time")
    feat4 = feat4.sort_values("time")
    merged = pd.merge_asof(df1m, feat5, on="time", direction="backward", tolerance=pd.Timedelta("5m"))
    merged = pd.merge_asof(merged, feat1, on="time", direction="backward", tolerance=pd.Timedelta("1h"))
    merged = pd.merge_asof(merged, feat4, on="time", direction="backward", tolerance=pd.Timedelta("4h"))
    # Uptrend & body strength
    merged["uptrend"] = (merged["close4h"] > merged["ema50_4h"]) & (merged["close1h"] > merged["ema50_1h"])
    merged["body_strength"] = candle_body_strength(merged["open"], merged["close"], merged["high"], merged["low"])
    # Feature columns
    merged["f_rsi5m"] = merged["rsi5m"]
    merged["f_ema_diff"] = merged["ema20_5m"] - merged["ema50_5m"]
    merged["f_ratio1h"] = (merged["close1h"] - merged["ema50_1h"]) / merged["ema50_1h"]
    merged["f_ratio4h"] = (merged["close4h"] - merged["ema50_4h"]) / merged["ema50_4h"]
    merged["f_ratio5m"] = (merged["close"] - merged["ema50_5m"]) / merged["ema50_5m"]
    merged["f_body_strength"] = merged["body_strength"]
    merged["prev_low"] = merged["low"].shift(1)
    merged["risk"] = merged["close"] - merged["prev_low"]
    return merged


def backtest(merged: pd.DataFrame, model, threshold: float = 0.66, horizon: int = 20) -> pd.DataFrame:
    """Run the long‑trade backtest on the merged DataFrame.

    This function filters the merged candles according to the strategy
    conditions, obtains model probabilities and simulates trades with a
    1.5 R take‑profit.  It returns a DataFrame of trades with the trade
    timestamp, entry, stop, target, model probability and outcome.
    """
    mask = (
        merged["uptrend"]
        & (merged["ema20_5m"] > merged["ema50_5m"])
        & (merged["rsi5m"] < 55.0)
        & (merged["risk"] > 0)
    )
    candidate_indices = np.where(mask)[0]
    feature_cols = ["f_rsi5m", "f_ema_diff", "f_ratio1h", "f_ratio4h", "f_ratio5m", "f_body_strength"]
    X = merged.loc[mask, feature_cols].values
    probs = model.predict_proba(X)[:, 1]
    highs = merged["high"].values
    lows = merged["low"].values
    closes = merged["close"].values
    prev_lows = merged["prev_low"].values
    times = merged["time"].values
    n = len(merged)
    horizon = int(horizon)
    trades: List[dict] = []
    for idx, prob in zip(candidate_indices, probs):
        if prob < threshold:
            continue
        entry = closes[idx]
        sl = prev_lows[idx]
        risk_price = entry - sl
        tp = entry + 1.5 * risk_price
        outcome = 0
        end_idx = min(idx + horizon, n - 1)
        for j in range(idx + 1, end_idx + 1):
            if highs[j] >= tp:
                outcome = 1
                break
            if lows[j] <= sl:
                outcome = 0
                break
        trades.append({
            "time": pd.to_datetime(times[idx]),
            "entry": entry,
            "stop": sl,
            "tp": tp,
            "probability": prob,
            "outcome": outcome,
        })
    return pd.DataFrame(trades)


def compute_weekly_summary(trades_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate trades by ISO week (starting on Monday).

    The returned DataFrame contains the number of trades, wins, losses and
    hit rate for each week.
    """
    trades_df = trades_df.copy()
    trades_df["week"] = trades_df["time"].dt.to_period("W-MON")
    grouped = trades_df.groupby("week").agg(
        trades=("outcome", "count"),
        wins=("outcome", "sum"),
    )
    grouped["losses"] = grouped["trades"] - grouped["wins"]
    grouped["accuracy"] = grouped["wins"] / grouped["trades"]
    return grouped.reset_index()


def main() -> None:
    parser = argparse.ArgumentParser(description="Backtest the one‑year BTCUSDT dataset using the long model.")
    parser.add_argument("--threshold", type=float, default=0.66, help="Probability threshold for taking a trade (default: 0.66)")
    parser.add_argument("--data_path", type=str, default="futures-trainedata", help="Path to the directory containing the kline zip files")
    parser.add_argument("--model", type=str, default="models/long_model_15R.pkl", help="Path to the trained model file")
    args = parser.parse_args()
    data_dir = Path(args.data_path)
    # Load data
    df1m = load_1m_candles(data_dir)
    df5m = load_tf_candles(data_dir, "5m")
    df1h = load_tf_candles(data_dir, "1h")
    df4h = load_tf_candles(data_dir, "4h")
    # Merge and feature engineering
    merged = build_merged(df1m, df5m, df1h, df4h)
    # Load model
    model_path = args.model
    if not os.path.exists(model_path):
        # Try relative to script location
        script_dir = Path(__file__).resolve().parent
        alt_path = script_dir / model_path
        if alt_path.exists():
            model_path = str(alt_path)
        else:
            raise FileNotFoundError(f"Model file not found: {args.model}")
    model = joblib.load(model_path)
    # Run backtest
    trades_df = backtest(merged, model, threshold=args.threshold, horizon=20)
    # Save trades
    trades_df.to_csv("trades_summary.csv", index=False)
    # Weekly summary
    weekly = compute_weekly_summary(trades_df)
    weekly.to_csv("weekly_summary.csv", index=False)
    total_trades = len(trades_df)
    wins = trades_df["outcome"].sum()
    accuracy = wins / total_trades if total_trades > 0 else 0.0
    print(f"Threshold: {args.threshold:.2f}")
    print(f"Total trades: {total_trades}")
    print(f"Winning trades: {wins}")
    print(f"Losing trades: {total_trades - wins}")
    print(f"Hit rate: {accuracy * 100:.2f}%")
    print(f"Weekly summary saved to weekly_summary.csv")


if __name__ == "__main__":
    main()