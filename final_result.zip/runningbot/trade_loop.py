import time
import os
from dotenv import load_dotenv
from datetime import datetime
from binance_api import get_price, place_market_order, place_sl_tp_orders
from trade_bot import TradeBot
from trade_logger import TradeLogger

  # 👈 Turn OFF after testing

# === Load env vars ===
load_dotenv()

# === Configs ===
TRADE_SYMBOL = os.getenv("TRADE_SYMBOL", "BTCUSDT")
LEVERAGE = int(os.getenv("LEVERAGE", 10))
RISK_USDT = float(os.getenv("RISK_USDT", 10))
# The take‑profit amount in USDT.  If not explicitly provided via the
# environment, default to a 1.5× reward‑to‑risk ratio based on ``RISK_USDT``.
TP_USDT = float(os.getenv("TP_USDT", RISK_USDT * 1.5))

# === Initialize bot and logger ===
bot = TradeBot(symbol=TRADE_SYMBOL, threshold=0.66)
logger = TradeLogger("data/trade_log.json")
open_trades = []

print("🔁 trade_loop.py started. Running live every 60s...")

while True:
    try:
        # === 1. Update candles and check signal ===
        bot.refresh_candles()
        signal = bot.generate_signal()

        if signal and logger.is_model_allowed("long"):
            entry_price = signal.entry_price
            sl_price = signal.stop_loss
            tp_price = signal.take_profit
            prob = signal.probability

            # Place a market order using the amount of USDT we are prepared to risk.  The
            # underlying API helper accepts only the notional USDT size and will derive
            # the position size based on the current price.  We intentionally do not
            # pass a ``leverage`` argument here because ``place_market_order`` in
            # ``binance_api.py`` does not accept it.  The leverage used on the
            # exchange should instead be configured at the account level or via
            # separate API calls if needed.  Passing an unsupported keyword caused
            # runtime errors in earlier versions of this loop.
            order = place_market_order(TRADE_SYMBOL, "BUY", RISK_USDT)
            if order:
                open_trades.append({
                    "id": datetime.utcnow().isoformat(),
                    "entry": entry_price,
                    "sl": sl_price,
                    "tp": tp_price,
                    "symbol": TRADE_SYMBOL,
                    "timestamp": datetime.utcnow().isoformat(),
                    "prob": prob
                })
                place_sl_tp_orders(
                    symbol=TRADE_SYMBOL,
                    position_side="LONG",
                    entry_price=entry_price,
                    stop_loss=sl_price,
                    take_profit=tp_price
                )
                print(f"✅ LONG placed @ {entry_price:.2f} | SL={sl_price:.2f} | TP={tp_price:.2f}")
        else:
            print("⛔ No valid signal or model filtered out.")

        # === 2. Monitor SL/TP ===
        new_open_trades = []
        current_price = get_price(TRADE_SYMBOL)
        for trade in open_trades:
            if current_price >= trade['tp']:
                print(f"🏁 TP hit: {current_price:.2f}")
                logger.log_trade(datetime.utcnow(), "long", "LONG", "win", TP_USDT, trade['prob'])
            elif current_price <= trade['sl']:
                print(f"💀 SL hit: {current_price:.2f}")
                logger.log_trade(datetime.utcnow(), "long", "LONG", "loss", -RISK_USDT, trade['prob'])
            else:
                new_open_trades.append(trade)

        open_trades = new_open_trades

    except Exception as e:
        print("[ERROR]", e)

    time.sleep(60)